import { useEffect } from 'react';
import { View, Text, FlatList, RefreshControl, StyleSheet } from 'react-native';
import { UserReponse } from '../../interfaces/pandoraApiResponse';
import { useUserApi } from '../../hooks/useUserApi';
import { UserCard } from '../../components/UserCard';
import { useNavigation, useIsFocused } from '@react-navigation/native';
import { BtnTouch } from '../../components/BtnTouch';
import type { StackNavigationProp } from '@react-navigation/stack';
import type { StackUserParams } from '../../navigator/UserStackNavigator';

export const HomeUser = () => {
  const { isLoading, loadUsers, listUser } = useUserApi();
  const focused = useIsFocused();
  const navigation = useNavigation<StackNavigationProp<StackUserParams>>();

  useEffect(() => {
    (!isLoading) && loadUsers();
  }, [focused]);

  const create: UserReponse = {
    id_user: 0,
    username: '',
    password: '',
    email: '',
    imagen: '',
    location: '',
    update: new Date(),
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={listUser}
        keyExtractor={(item) => `#${item.id_user}`}
        contentContainerStyle={styles.listContent}
        columnWrapperStyle={styles.columnWrapper}
        ListHeaderComponent={(
          <View style={styles.headerContainer}>
            <View>
              <Text style={styles.subtitle}>Directorio</Text>
              <Text style={styles.title}>Usuarios</Text>
            </View>
            <BtnTouch
              color="#2563EB"
              borderColor="#1D4ED8"
              text="+ Nuevo"
              borderWidth={1}
              style={styles.createButton}
              onPress={() => navigation.navigate('FormUser', { ...create })}
            />
          </View>
        )}
        refreshControl={(
          <RefreshControl
            refreshing={isLoading}
            onRefresh={loadUsers}
            colors={['#2563EB']}
            tintColor="#2563EB"
          />
        )}
        showsVerticalScrollIndicator={false}
        numColumns={2}
        renderItem={({ item }) => (
          <UserCard user={item} />
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#E2E8F0',
  },
  listContent: {
    paddingHorizontal: 16,
    paddingTop: 20,
    paddingBottom: 32,
  },
  columnWrapper: {
    justifyContent: 'space-between',
    marginBottom: 14,
  },
  headerContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
    paddingBottom: 14,
    borderBottomWidth: 1,
    borderBottomColor: '#CBD5E1',
  },
  subtitle: {
    fontSize: 12,
    fontWeight: '700',
    color: '#2563EB',
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  title: {
    fontSize: 28,
    fontWeight: '800',
    color: '#0F172A',
    marginTop: 2,
  },
  createButton: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 10,
  },
});