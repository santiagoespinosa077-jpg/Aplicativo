import { useEffect } from 'react';
import { View, Text, FlatList, RefreshControl, StyleSheet, StatusBar } from 'react-native';
import { TareaResponse, EstadoTarea } from '../../interfaces/pandoraApiResponse';
import { useTareaApi } from '../../hooks/useTareaApi';
import { TareaCard } from '../../components/TareaCard';
import { useNavigation, useIsFocused } from '@react-navigation/native';
import { BtnTouch } from '../../components/BtnTouch';
import type { StackNavigationProp } from '@react-navigation/stack';
import type { StackTareaParams } from '../../navigator/TareaStackNavigator';

export const HomeTareas = () => {
  const { isLoading, loadTarea, listTarea } = useTareaApi();
  const focused = useIsFocused();
  const navigation = useNavigation<StackNavigationProp<StackTareaParams>>();

  useEffect(() => {
    (!isLoading) && loadTarea();
  }, [focused]);

  const create: TareaResponse = {
    id_tarea: 0,
    titulo: '',
    descripcion: '',
    estado: EstadoTarea.pendiente,
  };

  return (
    <View style={styles.mainContainer}>
      <StatusBar barStyle="dark-content"  />

      <FlatList
        data={listTarea}
        keyExtractor={(item) => `#${item.id_tarea}`}
        contentContainerStyle={styles.listContent}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
        ListHeaderComponent={(
          <View style={styles.headerContainer}>
            <View>
              <Text style={styles.subtitle}>Actividades</Text>
              <Text style={styles.headerTitle}>Tareas</Text>
            </View>
            <BtnTouch
              color="#2563EB"
              borderColor="#1D4ED8"
              text="+ Nueva"
              borderWidth={1}
              style={styles.createButton}
              onPress={() => navigation.navigate('FormTarea', { ...create })}
            />
          </View>
        )}
        refreshControl={(
          <RefreshControl
            refreshing={isLoading}
            onRefresh={loadTarea}
            colors={['#2563EB']}
            tintColor="#2563EB"
          />
        )}
        showsVerticalScrollIndicator={false}
        numColumns={1}
        renderItem={({ item }) => (
          <TareaCard tarea={item} />
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
    backgroundColor: '#E2E8F0',
  },
  listContent: {
    paddingHorizontal: 16,
    paddingTop: 20,
    paddingBottom: 32,
  },
  headerContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
    paddingBottom: 14,
    borderBottomWidth: 1,
    borderBottomColor: '#CBD5E1',
  },
  subtitle: {
    fontSize: 12,
    fontWeight: '700',
    color: '#2563EB',
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: '800',
    color: '#0F172A',
    marginTop: 2,
  },
  createButton: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 10,
  },
  separator: {
    height: 12,
  },
});