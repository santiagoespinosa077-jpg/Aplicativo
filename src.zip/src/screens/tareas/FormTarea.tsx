import { useEffect } from 'react';
import { View, Text, TextInput, ScrollView, StyleSheet, StatusBar } from 'react-native';
import { BtnTouch } from '../../components/BtnTouch';
import { StackScreenProps } from '@react-navigation/stack';
import { StackTareaParams } from '../../navigator/TareaStackNavigator';
import { useTareaForm } from '../../hooks/useTareaForm';
import { siguienteEstado } from '../../interfaces/pandoraApiResponse';

interface Props extends StackScreenProps<StackTareaParams, 'FormTarea'> {}

const C = {
  fondo: '#E2E8F0',
  tarjeta: '#FFFFFF',
  superficieInput: '#F8FAFC',
  borde: '#CBD5E1',
  acento: '#2563EB',
  acentoBorde: '#1D4ED8',
  acentoSuave: '#DBEAFE',
  textoPrincipal: '#0F172A',
  textoSecundario: '#475569',
  placeholder: '#94A3B8',
  peligro: '#DC2626',
};

export const FormTarea = ({ route, navigation }: Props) => {
  const { state, handleInputChange, handleSubmit, handleDelete, handleUpdate } = useTareaForm();

  useEffect(() => {
    const tarea = route.params;
    handleInputChange('id_tarea', tarea.id_tarea);
    handleInputChange('titulo', tarea.titulo);
    handleInputChange('descripcion', tarea.descripcion);
    handleInputChange('estado', tarea.estado);
  }, []);

  return (
    <View style={styles.root}>
      <StatusBar barStyle="dark-content" />

      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.header}>
          <Text style={styles.kicker}>Gestión de tareas</Text>
          <Text style={styles.title}>
            {state.id_tarea === 0 ? 'Nueva tarea' : 'Editar tarea'}
          </Text>
          <Text style={styles.subtitle}>
            Gestiona el estado y los detalles de tu tarea
          </Text>
        </View>

        <View style={styles.card}>
          <View style={styles.topAccent} />

          <View style={styles.cardBody}>
            {state.id_tarea !== 0 && state.estado && (
              <View style={styles.statusBadge}>
                <Text style={styles.statusText}>
                  ESTADO ACTUAL: {String(state.estado).toUpperCase()}
                </Text>
              </View>
            )}

            <View style={styles.form}>
              <View style={styles.fieldGroup}>
                <Text style={styles.label}>TÍTULO DE LA TAREA</Text>
                <TextInput
                  style={styles.input}
                  value={state.titulo}
                  onChangeText={(text) => handleInputChange('titulo', text)}
                  placeholder="Escribe el título"
                  placeholderTextColor={C.placeholder}
                />
              </View>

              <View style={styles.fieldGroup}>
                <Text style={styles.label}>DESCRIPCIÓN</Text>
                <TextInput
                  style={[styles.input, styles.textArea]}
                  value={state.descripcion}
                  onChangeText={(text) => handleInputChange('descripcion', text)}
                  placeholder="Escribe una breve descripción..."
                  placeholderTextColor={C.placeholder}
                  multiline
                  textAlignVertical="top"
                />
              </View>

              <View style={styles.buttonGroup}>
                <BtnTouch
                  text={state.id_tarea === 0 ? 'Crear tarea' : 'Actualizar tarea'}
                  color={C.acento}
                  borderColor={C.acentoBorde}
                  borderWidth={1}
                  onPress={async () => {
                    await handleSubmit();
                    navigation.popToTop();
                  }}
                />

                {state.id_tarea !== 0 && (
                  <>
                    <View style={styles.actionMargin}>
                      <BtnTouch
                        text={`${siguienteEstado(state.estado)}`}
                        color="#0F172A"
                        borderColor="#0F172A"
                        borderWidth={1}
                        onPress={async () => {
                          await handleUpdate(siguienteEstado(state.estado));
                          navigation.popToTop();
                        }}
                      />
                    </View>

                    <View style={styles.actionMargin}>
                      <BtnTouch
                        text="Eliminar tarea"
                        color={C.peligro}
                        borderColor={C.peligro}
                        borderWidth={1}
                        onPress={async () => {
                          await handleDelete();
                          navigation.popToTop();
                        }}
                      />
                    </View>
                  </>
                )}
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

export default FormTarea;

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: C.fondo,
  },
  content: {
    paddingHorizontal: 18,
    paddingTop: 28,
    paddingBottom: 40,
  },
  header: {
    marginBottom: 20,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: C.borde,
  },
  kicker: {
    fontSize: 12,
    fontWeight: '700',
    color: C.acento,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  title: {
    color: C.textoPrincipal,
    fontSize: 28,
    fontWeight: '800',
    letterSpacing: -0.5,
    marginTop: 2,
  },
  subtitle: {
    color: C.textoSecundario,
    fontSize: 14,
    marginTop: 2,
  },
  card: {
    backgroundColor: C.tarjeta,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: C.borde,
    overflow: 'hidden',
    elevation: 2,
    shadowColor: '#0F172A',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
  },
  topAccent: {
    height: 5,
    width: '100%',
    backgroundColor: C.acento,
  },
  cardBody: {
    padding: 20,
  },
  statusBadge: {
    alignSelf: 'flex-start',
    backgroundColor: C.acentoSuave,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 8,
    marginBottom: 18,
    borderWidth: 1,
    borderColor: '#93C5FD',
  },
  statusText: {
    color: C.acentoBorde,
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 0.6,
  },
  form: {
    width: '100%',
  },
  fieldGroup: {
    marginBottom: 18,
  },
  label: {
    color: C.textoSecundario,
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 1,
    marginBottom: 6,
  },
  input: {
    backgroundColor: C.superficieInput,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: C.borde,
    color: C.textoPrincipal,
    fontSize: 15,
    height: 48,
    paddingHorizontal: 14,
  },
  textArea: {
    height: 110,
    paddingTop: 14,
    paddingBottom: 14,
  },
  buttonGroup: {
    marginTop: 10,
    alignItems: 'center',
  },
  actionMargin: {
    marginTop: 12,
  },
});