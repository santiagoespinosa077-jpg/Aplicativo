import { View, Text, TouchableOpacity, StyleSheet, Image, Dimensions } from 'react-native';
import { UserReponse } from '../interfaces/pandoraApiResponse';
import { useNavigation } from '@react-navigation/native';
import type { StackNavigationProp } from '@react-navigation/stack';
import type { StackUserParams } from '../navigator/UserStackNavigator';

interface Props {
  user: UserReponse;
}

const CARD_WIDTH = (Dimensions.get('window').width - 46) / 2;

export const UserCard = ({ user }: Props) => {
  const navigation = useNavigation<StackNavigationProp<StackUserParams>>();

  return (
    <TouchableOpacity
      activeOpacity={0.75}
      style={styles.cardContainer}
      onPress={() => navigation.navigate('FormUser', { ...user })}
    >
      <View style={styles.topAccent} />

      <View style={styles.cardBody}>
        <View style={styles.topRow}>
          <View style={styles.idBadge}>
            <Text style={styles.idBadgeText}>#{user.id_user}</Text>
          </View>
        </View>

        <View style={styles.avatarRing}>
          <Image
            style={styles.avatar}
            source={{ uri: `data:image/png;base64,${user.imagen}` }}
          />
        </View>

        <Text style={styles.username} numberOfLines={1}>
          {user.username}
        </Text>

        <Text style={styles.email} numberOfLines={1}>
          {user.email}
        </Text>

        <View style={styles.footer}>
          <Text style={styles.dateText} numberOfLines={1}>
            {new Date(user.update).toLocaleDateString()}
          </Text>
        </View>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  cardContainer: {
    width: CARD_WIDTH,
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#CBD5E1',
    overflow: 'hidden',
    elevation: 2,
    shadowColor: '#0F172A',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
  },
  topAccent: {
    height: 5,
    width: '100%',
    backgroundColor: '#2563EB',
  },
  cardBody: {
    padding: 14,
    alignItems: 'center',
  },
  topRow: {
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginBottom: 6,
  },
  idBadge: {
    backgroundColor: '#DBEAFE',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 6,
  },
  idBadgeText: {
    fontSize: 11,
    fontWeight: '700',
    color: '#1D4ED8',
  },
  avatarRing: {
    padding: 3,
    borderRadius: 38,
    borderWidth: 2,
    borderColor: '#93C5FD',
    marginBottom: 10,
  },
  avatar: {
    width: 62,
    height: 62,
    borderRadius: 31,
    backgroundColor: '#F1F5F9',
  },
  username: {
    fontSize: 15,
    fontWeight: '800',
    color: '#0F172A',
    textAlign: 'center',
    marginBottom: 3,
  },
  email: {
    fontSize: 12,
    color: '#475569',
    textAlign: 'center',
    marginBottom: 12,
  },
  footer: {
    width: '100%',
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: '#E2E8F0',
    alignItems: 'center',
    backgroundColor: '#F8FAFC',
    borderRadius: 6,
    paddingBottom: 4,
  },
  dateText: {
    fontSize: 11,
    color: '#334155',
    fontWeight: '600',
  },
});