import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { TareaResponse } from '../interfaces/pandoraApiResponse';
import { useNavigation } from '@react-navigation/native';
import type { StackNavigationProp } from '@react-navigation/stack';
import type { StackTareaParams } from '../navigator/TareaStackNavigator';

interface Props {
  tarea: TareaResponse;
}

const getStatusStyle = (estado: string) => {
  const normalizado = String(estado).toLowerCase();
  if (normalizado.includes('complet') || normalizado.includes('termin')) {
    return { bg: '#DCFCE7', border: '#86EFAC', text: '#15803D', accent: '#16A34A' };
  }
  if (normalizado.includes('proceso') || normalizado.includes('progreso')) {
    return { bg: '#FEF3C7', border: '#FCD34D', text: '#B45309', accent: '#D97706' };
  }
  return { bg: '#DBEAFE', border: '#93C5FD', text: '#1D4ED8', accent: '#2563EB' };
};

export const TareaCard = ({ tarea }: Props) => {
  const navigation = useNavigation<StackNavigationProp<StackTareaParams>>();
  const statusColors = getStatusStyle(String(tarea.estado));

  return (
    <TouchableOpacity
      activeOpacity={0.78}
      style={style.cardContainer}
      onPress={() => navigation.navigate('FormTarea', { ...tarea })}
    >
      <View style={[style.topAccent, { backgroundColor: statusColors.accent }]} />

      <View style={style.cardBody}>
        <View style={style.topRow}>
          <Text style={style.idText}>#{tarea.id_tarea}</Text>
          <View
            style={[
              style.statusBadge,
              {
                backgroundColor: statusColors.bg,
                borderColor: statusColors.border,
              },
            ]}
          >
            <Text style={[style.statusText, { color: statusColors.text }]}>
              {String(tarea.estado).toUpperCase()}
            </Text>
          </View>
        </View>

        <Text style={style.title} numberOfLines={2}>
          {tarea.titulo}
        </Text>

        <Text style={style.description} numberOfLines={3}>
          {tarea.descripcion}
        </Text>
      </View>
    </TouchableOpacity>
  );
};

const style = StyleSheet.create({
  cardContainer: {
    backgroundColor: '#FFFFFF',
    borderColor: '#CBD5E1',
    borderRadius: 14,
    borderWidth: 1,
    overflow: 'hidden',
    width: '100%',
    elevation: 2,
    shadowColor: '#0F172A',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
  },
  topAccent: {
    height: 5,
    width: '100%',
  },
  cardBody: {
    padding: 16,
  },
  topRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  idText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#64748B',
  },
  statusBadge: {
    paddingHorizontal: 10,
    paddingVertical: 3,
    borderRadius: 6,
    borderWidth: 1,
  },
  statusText: {
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 0.6,
  },
  title: {
    color: '#0F172A',
    fontSize: 17,
    fontWeight: '800',
    marginBottom: 6,
  },
  description: {
    color: '#475569',
    fontSize: 14,
    lineHeight: 20,
  },
});