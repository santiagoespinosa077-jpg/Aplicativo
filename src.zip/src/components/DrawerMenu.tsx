import { View, Text, Image, TouchableOpacity, StyleSheet } from "react-native";
import { DrawerContentScrollView, DrawerContentComponentProps } from "@react-navigation/drawer";
import { AuthContext } from "../context/AuthContext";
import { useContext } from "react";
import { BtnTouch } from "./BtnTouch";

interface BtnProps {
  navigate: () => void;
  text: string;
}

const BtnMenu = ({ navigate, text }: BtnProps) => {
  return (
    <TouchableOpacity
      activeOpacity={0.7}
      onPress={navigate}
      style={style.menuItem}
    >
      <Text style={style.menuText}>{text}</Text>
      <Text style={style.menuArrow}>›</Text>
    </TouchableOpacity>
  );
};

export const DrawerMenu = ({ navigation }: DrawerContentComponentProps) => {
  const { authState, logout } = useContext(AuthContext);

  return (
    <DrawerContentScrollView contentContainerStyle={style.container}>
      <View style={style.header}>
        <View style={style.avatarWrapper}>
          <Image
            style={style.avatar}
            source={
              authState.isLoggedIn
                ? { uri: `data:image/png;base64,${authState.avatar}` }
                : { uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSqMRKTwf-zYsaWB9QU5hXY8PBNLgQo61e5ML_g6P4NWA&s=10' }
            }
          />
        </View>
        <Text style={style.userText} numberOfLines={1}>
          {authState.username}
        </Text>
        <Text style={style.userLabel}>
          {authState.isLoggedIn ? 'Sesión iniciada' : 'Sin sesión'}
        </Text>
      </View>

      {/* Opciones */}
      <View style={style.menu}>
        <BtnMenu navigate={() => navigation.navigate('StackNavigator')} text="Bolitas y palitos" />
        <BtnMenu navigate={() => navigation.navigate('PokemonNavigator')} text="Pokedex" />
        <BtnMenu navigate={() => navigation.navigate('FormScreen')} text="FormScreen" />
        <BtnMenu navigate={() => navigation.navigate('ImagePickerScreen')} text="Seleccionar Image" />
        <BtnMenu navigate={() => navigation.navigate('LocationScreen')} text="Localización" />
        <BtnMenu navigate={() => navigation.navigate('UserStackNavigator')} text="Gestión de Usuarios" />
        <BtnMenu navigate={() => navigation.navigate('TareaStackNavigator')} text="Tareas" />
        <BtnMenu navigate={() => navigation.navigate('MantenimientoStackNavigator')} text="Mantenimiento" />
        <BtnMenu navigate={() => navigation.navigate('DataResponseScreen')} text="Graficos" />
        <BtnMenu navigate={() => navigation.navigate('CalificacionDataScreen')} text="Calificacion Data" />
        
      </View>
      
      {authState.isLoggedIn && (
        <View style={style.footer}>
          <BtnTouch
            text="Cerrar sesión"
            color="red"
            onPress={() => logout()}
          />
        </View>
      )}
    </DrawerContentScrollView>
  );
};

const style = StyleSheet.create({
  drawerBackground: {
    backgroundColor: '#f8fafc',
  },
  container: {
    paddingBottom: 28,
  },
  header: {
    alignItems: 'center',
    paddingVertical: 28,
    paddingHorizontal: 18,
    marginHorizontal: 12,
    marginTop: 8,
    backgroundColor: '#0f172a',
    borderRadius: 24,
    shadowColor: '#0f172a',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.2,
    shadowRadius: 10,
    elevation: 6,
  },
  avatarWrapper: {
    position: 'relative',
    padding: 4,
    borderRadius: 65,
    borderWidth: 2,
    borderColor: '#38bdf8',
    backgroundColor: '#1e293b',
  },
  avatar: {
    height: 96,
    width: 96,
    borderRadius: 48,
  },
  statusIndicator: {
    position: 'absolute',
    bottom: 4,
    right: 4,
    width: 18,
    height: 18,
    borderRadius: 9,
    borderWidth: 3,
    borderColor: '#0f172a',
  },
  userText: {
    marginTop: 14,
    fontSize: 20,
    fontWeight: '700',
    color: '#f8fafc',
    textAlign: 'center',
    letterSpacing: 0.3,
  },
  statusPill: {
    marginTop: 8,
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 20,
  },
  statusPillActive: {
    backgroundColor: 'rgba(34, 197, 94, 0.15)',
  },
  statusPillInactive: {
    backgroundColor: 'rgba(148, 163, 184, 0.15)',
  },
  userLabel: {
    fontSize: 12,
    fontWeight: '600',
    letterSpacing: 0.4,
  },
  sectionTitle: {
    fontSize: 11,
    fontWeight: '700',
    color: '#94a3b8',
    letterSpacing: 1.2,
    marginLeft: 6,
    marginBottom: 10,
  },
  menu: {
    marginTop: 22,
    paddingHorizontal: 14,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#ffffff',
    paddingVertical: 13,
    paddingHorizontal: 16,
    borderRadius: 14,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    shadowColor: '#0f172a',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.04,
    shadowRadius: 3,
    elevation: 1,
  },
  menuLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  dot: {
    width: 7,
    height: 7,
    borderRadius: 4,
    backgroundColor: '#3b82f6',
    marginRight: 12,
  },
  menuText: {
    fontSize: 15,
    color: '#1e293b',
    fontWeight: '600',
  },
  arrowBadge: {
    width: 26,
    height: 26,
    borderRadius: 8,
    backgroundColor: '#f1f5f9',
    alignItems: 'center',
    justifyContent: 'center',
  },
  menuArrow: {
    fontSize: 18,
    color: '#475569',
    fontWeight: '600',
    lineHeight: 20,
  },
  footer: {
    marginTop: 18,
    paddingTop: 16,
    marginHorizontal: 14,
    borderTopWidth: 1,
    borderTopColor: '#e2e8f0',
    alignItems: 'center',
  },
});