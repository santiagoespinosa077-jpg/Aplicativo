import { useReducer, useState, useContext } from "react";
import { AuthContext } from "../context/AuthContext";
import { LoginReponse } from "../interfaces/pandoraApiResponse";
import { cachasApi } from "../api/cachasApi";
import { obtenerApiUrlActual } from "../config/api";

export interface LoginData {
  email: string;
  password: string;
}

export interface UseLogin {
  isLoading: boolean;
  state: LoginData;
  handleLogin: () => void;
  handleInputChange: ( fieldName: keyof LoginData, value: string ) => void;
  request: LoginReponse;
}

export const useLogin = () => {

  const initialState: LoginData = {
    email: '',
    password: ''
  }

  type Action = { type: 'handleInputChange', payload: { fieldName: keyof LoginData, value: string } };

  const dataReducer = ( state: LoginData, action: Action ) => {
    switch( action.type ){
      case 'handleInputChange':
        return {
          ...state,
          [ action.payload.fieldName ] : action.payload.value
      }
    }
  }

  const [ isLoading, setIsLoading ] = useState<boolean>(false);
  const [ error, setError ] = useState<string>('');
  const [ state, dispatch ] = useReducer( dataReducer, initialState );
  const [ request, setRequest ] = useState<LoginReponse>({} as LoginReponse);
  const { singIn, changeUsername, changeAvatar } = useContext( AuthContext );
 
  const handleInputChange = ( fieldName: keyof LoginData, value: string ) => {
    dispatch({ type: 'handleInputChange', payload: { fieldName, value } });
  }
 
  const handleLogin = async () => {
    setIsLoading(true);
    setError('');
 
    try {
      const response = await cachasApi.post<LoginReponse>(
        `${obtenerApiUrlActual()}/users/login`,
        { email: state.email, password: state.password }
      );
 
      setRequest( response.data );
 
      if (response.data) {
        singIn();
        response.data.username && changeUsername(response.data.username);
        response.data.imagen && changeAvatar(response.data.imagen);
      }
    } catch (e: any) {
      setError(
        e?.response
          ? 'Correo o contraseña incorrectos'
          : 'No se pudo conectar con el servidor. Revisa la dirección IP.'
      );
    } finally {
      setIsLoading(false);
    }
  }
 
  return { isLoading, error, state, handleLogin, handleInputChange, request };
 
}